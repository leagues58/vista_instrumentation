/*
===============================================================================
                            COPYRIGHT NOTICE

    Copyright (C) 2012 Vista Instrumentation LLC
    International Copyright Secured.  All Rights Reserved.

-------------------------------------------------------------------------------

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

   o Redistributions of source code must retain the above copyright notice, this
     list of conditions and the following disclaimer.
   o Redistributions in binary form must reproduce the above copyright notice,
     this list of conditions and the following disclaimer in the documentation
     and/or other materials provided with the distribution.
   o Neither the name of Vista Instrumentation nor the names of its contributors may be used
     to endorse or promote products derived from this software without specific
     prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================
*/

/*
 * VistaCtrl.c -- a datagram sockets "client" demo
 *                Demonstrates how to connect to and control
 *                the Vista Geometry System RECORD server
*/

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>

#include "VistaCtrl.h"
#include "cmd_strings.h"
#include "warnings.h"
#include "die.h"

extern char getch(void);            // Used to get keyboard chars

#define BCAST_PORT "1029"           // the port users will be connecting to

static int bcast_sock_fd = 0;       // Socket file descriptor for reading broadcast state packets
static int ctrl_sock_fd = 0;        // Socket file descriptor server control functions
static char rt_file[MAX_PATH];      // The current geometry file name is stored here

// Server network address filled out by udp_comm_thread()
static char   server_ip_addr[16] = {0};
static int    server_port = 0;

// Structure for lapsed timer
typedef struct prof_timer_t {
   LARGE_INTEGER time_start;
   LARGE_INTEGER time_stop;
} prof_timer_t;

#define START_TIMER (1)

// lapsed_time() implements a simple timer
// *timer is working storage provided by the calling function
// start is set to START_TIMER to init the timer, 0 to get the lapsed time.
// lapsed time is returned in usec's
// resolution is system dependant

int lapsed_time(prof_timer_t *timer, int start)
{
   static LARGE_INTEGER freq;
   static first_call = 1;
   double duration;
   int lapsed_time;

   if (first_call) {
      QueryPerformanceFrequency(&freq);
      first_call = 0;
   }

   if (start == START_TIMER) {
      QueryPerformanceCounter(&timer->time_start);
      return(0);
   }
   QueryPerformanceCounter(&timer->time_stop);
   duration = (double)(timer->time_stop.QuadPart-timer->time_start.QuadPart)/(double)freq.QuadPart;

   lapsed_time = duration * 1000000;
   return(lapsed_time);                                        // Return the time in usec
}

// recording_paused() is called when data recording is indicated as paused by the RECORD SERVER.
// The arg is the existing file name.

int recording_paused(char *filename)
{
   // Recording has been switched on.
   // Do whatever is necessary when a new data file is opened
   printf("\nRecording Paused  File->%s\n", filename);
   return(0);
}


// recording_started() is called when data recording is started by the RECORD SERVER.
// The arg is the new file name.

int recording_started(char *filename)
{
   // Recording has been switched on.
   // Do whatever is necessary when a new data file is opened
   printf("\nRecording On  File->%s\n", filename);
   return(0);
}

// recording_stopped() is called when data recording is stopped by the RECORD SERVER.

int recording_stopped(void)
{
   // Recording has been switched off.
   // Do whatever is necessary to finish processing the data file
   printf("\nRecording Off\n");
   return(0);
}

// listen_func() is used by udp_comm_thread() to receive the broadcast state packets
// It listens on the port defined by BCAST_PORT

char *listen_func(void)
{
   struct addrinfo hints, *servinfo, *p;
   int rv;
   int numbytes;
   int recv_timeout;
   char yes = 1;
   socklen_t addr_len;
   struct sockaddr_in their_addr; // connector's address information
   #define MAXBUFLEN (0x2000)
   static char buf[MAXBUFLEN];

   if (bcast_sock_fd == 0) {         // Open socket if not already open

      memset(&hints, 0, sizeof(hints));
      hints.ai_family = AF_INET;         // set to AF_INET to force IPv4
      hints.ai_socktype = SOCK_DGRAM;    // UDP
      hints.ai_flags = AI_PASSIVE;       // use my IP

      if ((rv = getaddrinfo(NULL, BCAST_PORT, &hints, &servinfo)) != 0) {
          die(__LINE__, __FILE__, (char *)gai_strerror(rv));
      }

      // loop through all the results and bind to the first we can
      for(p = servinfo; p != NULL; p = p->ai_next) {
         {
            void *addr;
            struct sockaddr_in *ipv4 = (struct sockaddr_in *)p->ai_addr;
            char ipstr[128];
            addr = &(ipv4->sin_addr);
            inet_ntop(p->ai_family, addr, ipstr, sizeof ipstr);
            addr = NULL;
         }
         if ((bcast_sock_fd = socket(p->ai_family, p->ai_socktype,
                 p->ai_protocol)) == -1) {
             perror("listener: socket");
             continue;
         }

         if (setsockopt(bcast_sock_fd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(char)) == -1) {
             perror("setsockopt");
             exit(1);
         }

         recv_timeout = 2000;    // Wait no more than 2 secs (2000 msec)

         if (setsockopt(bcast_sock_fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&recv_timeout,
             sizeof recv_timeout) == -1) {
            die(__LINE__, __FILE__, strerror(errno));
         }

         if (bind(bcast_sock_fd, p->ai_addr, p->ai_addrlen) == -1) {
             closesocket(bcast_sock_fd);
             perror("listener: bind");
             continue;
         }

         break;
      }

      if (p == NULL) {
         fprintf(stderr, "listener: failed to bind socket\n");
         return NULL;
      }

      freeaddrinfo(servinfo);
   }


   //printf("listener: waiting to recvfrom...\n");

   addr_len = sizeof their_addr;
   if ((numbytes = recvfrom(bcast_sock_fd, buf, MAXBUFLEN-1 , 0,
       (struct sockaddr *)&their_addr, &addr_len)) == -1) {
      int err;
      if ((err = WSAGetLastError()) == WSAETIMEDOUT) {
         numbytes = 0;
      }
      else {
         die(__LINE__, __FILE__, "Error return from recvfrom()");
      }
   }


   buf[numbytes] = '\0';   // Terminate the received string

   //printf("listener: packet contains \"%s\"\n", buf);

   return(buf);

   return 0;
}

// server_cmd() sends a command to the RECORD server and waits for a response.
// This function assumes the IP:port address has been filled out by udp_comm_thread()
//
// char *msg   pointer to command string to send
// char *resp  pointer to response buffer

char *server_cmd(char *msg, char *resp)
{
   static struct sockaddr_in server_addr;
   static struct hostent *he;
   int numbytes, len;
   int recv_timeout;

   char *recv_bufr = resp;

   // Setup the socket on first call

   if (ctrl_sock_fd == 0) {

      if ((ctrl_sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
         die(__LINE__, __FILE__, strerror(errno));
      }

      // Set a read timeout so that if no server is reachable, we won't get stuck.

      recv_timeout = 2000;    // Wait no more than 2 secs (2000 msec)

      if (setsockopt(ctrl_sock_fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&recv_timeout,
          sizeof recv_timeout) == -1) {
         die(__LINE__, __FILE__, strerror(errno));
      }
   }

   // Setup the network address struct used to communicate with the server

   if ((he=gethostbyname(server_ip_addr)) == NULL) {
       die(__LINE__, __FILE__, strerror(errno));
   }

   server_addr.sin_family = AF_INET;     // host byte order
   server_addr.sin_port = htons(server_port); // short, network byte order
   server_addr.sin_addr = *((struct in_addr *)he->h_addr);
   memset(server_addr.sin_zero, 0, sizeof server_addr.sin_zero);

   if ((numbytes=sendto(ctrl_sock_fd, msg, strlen(msg), 0,
            (struct sockaddr *)&server_addr, sizeof server_addr)) == -1) {
      die(__LINE__, __FILE__, strerror(errno));
   }

   //printf("sent %d bytes to %s\n", numbytes,
   //    inet_ntoa(server_addr.sin_addr));

   recv_bufr[0] = 0;
   len = sizeof(server_addr);
   if ((numbytes=recvfrom(ctrl_sock_fd, recv_bufr, SERVER_RESPONSE_LEN-1, 0, (struct sockaddr *)&server_addr, &len)) == -1) {
      int err;
      if ((err = WSAGetLastError()) == WSAETIMEDOUT) {
         numbytes = 0;
      }
      else {
         die(__LINE__, __FILE__, "Error return from recvfrom() err = %d", err);
      }
   }

   recv_bufr[numbytes] = 0;

   //printf("Received %d bytes: %s\n", numbytes, recv_bufr);

   return (recv_bufr);
}


DWORD WINAPI udp_comm_thread(void *arg)
{
   // This thread communicates with the OpenGeo 'record' program.  It listens
   // on UDP port 1029 for record status messages.  When it seen that
   // recording is 'ON' it parses the server response string to get
   // the current filename.

   // Call with arg = 1  to start the thread
   // Call with arg = -1 to stop the thread

   char *server_msg;


   static HANDLE  thread_handle = (HANDLE)-1;
   static DWORD   ThreadId;

   static int thread_shutdown = 0;

   int recording, state, prof_state;
   int dot_quad[4], port;
   int rc;

   #define MAX_TIMEOUT (5)
   int timeout_cnt;

   if (arg != NULL) {

      if (((int)arg) == 1) {
         if (thread_handle != (HANDLE)-1) {
            die(__LINE__,__FILE__, "thread already running");
         }

         thread_handle = CreateThread(NULL, 0, udp_comm_thread, NULL, 0, &ThreadId);
         if (thread_handle == NULL) {
            die(__LINE__,__FILE__, "Cannot create thread");
         }
         return((DWORD)thread_handle);
      }

      if (((int)arg) == -1) {                                    // Shutdown logic

         if (thread_handle == (HANDLE)-1) {
            if (verbose) printf("shutdown request but not running");
            return(0);          // Can't shutdown, not running
         }

         thread_shutdown = TRUE;                         // Set shutdown req flag
         WaitForSingleObject(thread_handle, 10000);      // wait for thread to ternimate
         thread_handle = (HANDLE) -1;                    // Indicate no longer running

         return(0);
      }
   }

   thread_shutdown = 0;
   printf("udp_comm_thread() Running\n");

   rt_file[0] = 0;
   timeout_cnt = 0;
   recording = 0;

   // Until requested to shutdown, read and parse UDP packets.

   while (!thread_shutdown) {

      if ((server_msg = listen_func()) == NULL) {

         // Time out is used to allow for thread shutdown

         if (++timeout_cnt > MAX_TIMEOUT) break;
         timeout_cnt = 0;
         continue;
      }

      // server_msg is NULL terminated by listen_func()
      // Sample string: "VGS_REC 192.168.0.221:5001, 1, 0, <0_C1231000>"  if recording is 'on'
      // Sample string: "VGS_REC 192.168.0.221:5001, 0, 0, <>"            if recording is 'off'

      // Be sure the string is not too long.  We don't want to overflow the
      // file name buffer.

      if (strlen(server_msg) < MAX_PATH) {

         // Parse the string
         rc = sscanf(server_msg, "VGS_REC %d.%d.%d.%d:%d, %d, %d, '%[^']",
                     &dot_quad[0], &dot_quad[1], &dot_quad[2], &dot_quad[3], &port,
                     &state, &prof_state, rt_file);

         // Ignore if not properly formatted

         if (rc == 8) {

            if (ctrl_sock_fd == 0) {
               sprintf(server_ip_addr, "%d.%d.%d.%d",
                       dot_quad[0], dot_quad[1], dot_quad[2], dot_quad[3]);
               server_port = port;
            }

            // Has the recording state changed?

            if (state != recording) {
               if (state) {
                  if (state == 1) {
                     // New file
                     recording_started(rt_file);
                  }
                  else {
                     // New file
                     recording_paused(rt_file);
                  }
               }
               else {
                  // Recording has been switched off.
                  recording_stopped();
               }
               recording = state;   // Save the new state
            }
            timeout_cnt = 0;
         }
      }
      else {
         // Unknown message
         printf("MSG-> %s\n", server_msg);
      }
   }

   if (ctrl_sock_fd != 0) closesocket(ctrl_sock_fd);
   ctrl_sock_fd = 0;
   thread_handle = (HANDLE)-1;
   printf("udp_comm_thread() shutdown\n");

   return(0);
}


int get_value(char *msg, char *fmt, int lower_limit, int upper_limit)
{
   // Get a numeric value from the keyboard

   // char *msg            Prompt string
   // char *fmt            Format string used by scanf()
   // int lower_limit      Lower range value
   // int upper_limit      Upper range value

   int rc, value;
   char bufr[256];

   while (1) {
      printf("%s", msg);
      if (fgets(bufr, 256, stdin) != NULL) {
         rc = sscanf(bufr, fmt, &value);
         if ((rc != 1) || (value < lower_limit) || (value > upper_limit)) {
            printf("***ERR Invalid value\n");
            continue;
         }
         break;
      }
   }
   return(value);
}

int main(int argc, char *argv)
{
   int c;
   WSADATA wsaData;
   static WORD wVersionRequested = 0;

   int err, len, i, done;
   char msg[256];
   char filename[256];
   char resp_bufr[SERVER_RESPONSE_LEN];
   prof_timer_t timer;

   setbuf(stdout, NULL);             // Turn off output buffering

   // First, make use the WINSOCK dll is OK and init'ed

   wVersionRequested = MAKEWORD( 2, 2 );

   err = WSAStartup( wVersionRequested, &wsaData );
   if ( err != 0 ) {
       return(0);            // No WinSock DLL
   }

   // Confirm that the WinSock DLL supports 2.2.

   if ( LOBYTE( wsaData.wVersion ) != 2 ||
           HIBYTE( wsaData.wVersion ) != 2 ) {
       WSACleanup( );
       printf("\n*** ERR Can use this version of WinSock DLL\n\n");
       return(0);            // WinSock DLL out of date
   }

   // The WinSock DLL is acceptable. Proceed.

   // Start the state packet monitor thread
   udp_comm_thread((void *)1);

   // Wait for up to 2 seconds for a state packet.  We need this so that we can
   // find the server.

   printf("\n\n+++ Vista Geometry System Control Demonstration PGM V1.2 +++\n\n");

   printf("Waiting for RECORD state packet...");
   lapsed_time(&timer, START_TIMER);
   while (server_port == 0) {
      if (lapsed_time(&timer, 0) >= 2000000) {      // Wait up to 2 seconds
         DIE("Cannot find RECORD server");
      }
      Sleep(100);           // Sleep for 100 ms
   }
   printf("server at %s:%d\n", server_ip_addr, server_port);;
   done = 0;

   while (!done) {

      // Print the command list for keyboard control

      printf("\n");
      printf("R/r   Start recording (Upper case=enter filename)\n");
      printf("S     Stop recording\n");
      printf("P     Pause recording\n");
      printf("U     Un-pause recording\n");
      printf("F/f   New file (Upper case=enter filename)\n");
      printf("G     Set gauge pnt <value>\n");
      printf("L     Load post\n");
      printf("I     Auto post increment\n");
      printf("D     Auto post decrement\n");
      printf("N     Next Post INC or DEC post\n");
      printf("O     Turn off auto post mode\n");
      printf("A     Turn on auto recording mode\n");
      printf("M     Turn off auto recording mode\n");
      printf("E     Set event\n");
      printf("H     Load user header data\n");
      printf("T     Load hardware tach reg\n");
      printf("1     Enable PROFILE recording\n");
      printf("2     Disable PROFILE recording\n");
      printf("X     Exit\n");

      printf("Enter a command:");


      c = getch();
      printf("%c\n", c);           // Echo the char

      switch (c) {
         case 'r': case 'R': {                        // Start recording
            filename[0] = 0;

            // If 'R' was entered, read a filename from the keyboard
            // otherwise the filename will be an empty string.

            if (c == 'R') {
               printf("Enter a file name: ");
               fgets(filename, 256, stdin);
               len = strlen(filename);
               // Strip the newline char
               for (i=len-1; i>=0; i--) {
                  if (filename[i] == '\n') {
                     filename[i] = 0;
                     break;
                  }
               }
            }

            sprintf(msg, "%s %s", STRT, filename);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 's': case 'S': {                        // Stop recording
            sprintf(msg, "%s", STOP);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'p': case 'P': {
            sprintf(msg, "%s", PAUSE);                // Pause
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'u': case 'U': {
            sprintf(msg, "%s", RUN);                  // Un-pause
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'f': case 'F': {                       // New file
            filename[0] = 0;

            // If 'F' was entered, read a filename from the keyboard
            // otherwise the filename will be an empty string.

            if (c == 'F') {
               printf("Enter a file name: ");
               fgets(filename, 256, stdin);
               len = strlen(filename);
               // Strip the newline char
               for (i=len-1; i>=0; i--) {
                  if (filename[i] == '\n') {
                     filename[i] = 0;
                     break;
                  }
               }
            }

            sprintf(msg, "%s %s", NEW_FILE, filename);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }


         case 'l': case 'L': {                        // Post
            // Get the post args from the keyboard
            int new_post, new_dist, nxt_post, nxt_dist;
            new_post = get_value("Enter new post (0-9999) : ", "%d", 0, 9999);
            new_dist = get_value("Enter new dist (0-6000) : ", "%d", 0, 6000);
            nxt_post = get_value("Enter next post (0-9999) : ", "%d", 0, 9999);
            nxt_dist = get_value("Enter next dist (0-6000) : ", "%d", 0, 6000);

            sprintf(msg, "%s %d %d %d %d", POST, new_post, new_dist, nxt_post, nxt_dist);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'i': case 'I': {                        // Turn on auto post increment
            int length;
            // Get the nonimal post length from the keyboard
            length = get_value("Enter normal sample count (0-6000) : ", "%d", 0, 6000);
            sprintf(msg, "%s %d", AUTO_POST_INC, length);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'd': case 'D': {                        // Turn on auto post decrement
            int length;
            // Get the nonimal post length from the keyboard
            length = get_value("Enter normal sample count (0-6000) : ", "%d", 0, 6000);
            sprintf(msg, "%s %d", AUTO_POST_DEC, length);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'o': case 'O': {                        // Turn off auto post inc/dec
            sprintf(msg, "%s", AUTO_POST_OFF);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'a': case 'A': {
            sprintf(msg, "%s", AUTO_REC_ON);          // Turn on automatic recording
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'n': case 'N': {
            sprintf(msg, "%s", NEXT_POST);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'm': case 'M': {
            sprintf(msg, "%s", AUTO_REC_OFF);         // Turn off automatic recording
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case '1': case '2': {
            sprintf(msg, "%s", (c=='1') ? PROF_ON : PROF_OFF);   // Turn on/off profile recording
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'e': case 'E': {                        // Load event
            unsigned int event_word;
            int rc;
            char bufr[256];

            // Read a hex event word from the keyboard

            while (1) {
               printf("Enter 32 bit hex event word (0-ffffffff) : ");
               if (fgets(bufr, 256, stdin) != NULL) {
                  rc = sscanf(bufr, "%x", &event_word);
                  if (rc != 1) {
                     printf("***ERR Invalid value\n");
                     continue;
                  }
                  break;
               }
            }
            sprintf(msg, "%s %x", EVENT, event_word);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }


      case 'g': case 'G': {                        // Set gauge pnt
         int gauge_pnt;
         int rc;
         char bufr[256];

         // Read a decimal integer number from the keyboard

         while (1) {
            printf("Enter gauge point value in 1/100 mm (300 > gp > 1900) : ");
            if (fgets(bufr, 256, stdin) != NULL) {
               rc = sscanf(bufr, "%d", &gauge_pnt);
               if (rc != 1) {
                  printf("***ERR Invalid value\n");
                  continue;
               }
               break;
            }
         }
         sprintf(msg, "%s %d", GAUGE_PNT, gauge_pnt);
         server_cmd(msg, resp_bufr);
         printf("Resp: %s\n", resp_bufr);
         break;
      }

      case 't': case 'T': {                        // Load tach reg
         int tach_value;
         int rc;
         char bufr[256];

         // Read a hex event word from the keyboard

         while (1) {
            printf("Enter tach value : ");
            if (fgets(bufr, 256, stdin) != NULL) {
               rc = sscanf(bufr, "%d", &tach_value);
               if (rc != 1) {
                  printf("***ERR Invalid value\n");
                  continue;
               }
               break;
            }
         }
         sprintf(msg, "%s %d", LD_TACH, tach_value);
         server_cmd(msg, resp_bufr);
         printf("Resp: %s\n", resp_bufr);
         break;
      }


         case 'h': case 'H': {                        // Load user data
            char bufr[256];

            // Read a string for user header data from the keyboard

            printf("Enter user data string (limited to 1 line) : ");
            fgets(bufr, 256, stdin);
            if (bufr[strlen(bufr)-1] == '\n') {         // Strip the newline char
               bufr[strlen(bufr)-1] = 0;
            }
            sprintf(msg, "%s %s", USER_DATA, bufr);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'b': case 'B': {                        // Trigger parity error
            unsigned int unit;
            int rc;
            char bufr[256];

            // Read a hex event word from the keyboard

            while (1) {
               printf("Enter gyro number : ");
               if (fgets(bufr, 256, stdin) != NULL) {
                  rc = sscanf(bufr, "%d", &unit);
                  if (rc != 1) {
                     printf("***ERR Invalid value\n");
                     continue;
                  }
                  break;
               }
            }
            sprintf(msg, "%s %d", PAR_ERROR, unit);
            server_cmd(msg, resp_bufr);
            printf("Resp: %s\n", resp_bufr);
            break;
         }

         case 'x': case 'X': {                        // Exit the pgm
            done = 1;
            break;
         }

         default: {                                   // Undefined key typed
            printf("***ERR Invalid entry\n");
            break;
         }
      }
   }

   udp_comm_thread((void *)-1);        // Shutdown the state packet thread

   exit(0);                            // Exit
}

