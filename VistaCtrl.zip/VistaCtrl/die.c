/*
===============================================================================
                            COPYRIGHT NOTICE

    Copyright (C) 2012 Vista Instrumentation LLC
    International Copyright Secured.  All Rights Reserved.

-------------------------------------------------------------------------------

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

   o Redistributions of source code must retain the above copyright notice, this
     list of conditions and the following disclaimer.
   o Redistributions in binary form must reproduce the above copyright notice,
     this list of conditions and the following disclaimer in the documentation
     and/or other materials provided with the distribution.
   o Neither the name of Vista Instrumentation nor the names of its contributors may be used
     to endorse or promote products derived from this software without specific
     prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================
*/

// Program termination routines

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include "die.h"
#include "warnings.h"              // Get rid of clutter warnings

extern char getch(void);

int verbose = 0;

#define N_ON_EXIT_FUNCS (20)

struct ON_EXIT_BLK {
   on_exit_func_t func;
   struct ON_EXIT_BLK *prev;
   struct ON_EXIT_BLK *next;
};

static struct ON_EXIT_BLK *oeb_head = NULL;    // Head of on_exit() function list




// On-exit functions are registered by adding a pointer to the function
// to a double linked list.  This makes it easier to remove a function if
// it is no longer needed.

// Function to malloc a new on-exit blk
struct ON_EXIT_BLK *get_new_oeb(void)
{
   struct ON_EXIT_BLK *oeb;

   if ((oeb = malloc(sizeof(struct ON_EXIT_BLK))) == NULL) {
      DIE("Cannot malloc mem of ON_EXIT_BLK");
   }

   return(oeb);
}


void register_on_exit_func(on_exit_func_t on_exit_func)
{
   struct ON_EXIT_BLK *oeb;

   if (oeb_head == NULL) {               // This is the first function to be registered
      oeb_head = get_new_oeb();          // Get a new blk and load the head pointer
      oeb_head->func = on_exit_func;     // Save the function address
      oeb_head->prev = NULL;             // This is the first blk so there is no previous
      oeb_head->next = NULL;             // There are no more so zero the next field
   }
   else {                                // Walk the list to find the end
      oeb = oeb_head;                    // Start at the head
      while (oeb->next) oeb = oeb->next; // Search for the end of the list (next == NULL)
      oeb->next = get_new_oeb();         // Get a new blk and put it at the end of the list
      oeb->next->prev = oeb;             // Save the back link in the new blk
      oeb = oeb->next;                   // Point to the new blk
      oeb->func = on_exit_func;          // Save the function address
      oeb->next = NULL;                  // There are no more so zero the next field
   }

   return;
}

int deregister_on_exit_func(on_exit_func_t on_exit_func)
{
   struct ON_EXIT_BLK *oeb, *deleted_oeb;

   if (oeb_head == NULL) return(-1);
   oeb = oeb_head;                    // Start at the head

   do {
      if (oeb->func == on_exit_func) {
         if (oeb->prev == NULL) {        // This is the first blk
            if (oeb->next == NULL) {     // It is also the last blk, i.e. there is only one
               free(oeb);
               oeb_head = NULL;
               return(0);
            }
            else {
               deleted_oeb = oeb;        // First blk, but not the last, save it's addr
               oeb = oeb->next;          // Get pointer to the next blk which will become the first
               oeb->prev = NULL;         // Now there is no prev because it becomes the first
               oeb_head = oeb;           // Point the head at it
               free(deleted_oeb);        // Free the old first blk
               return(0);
            }
         }
         else {                          // Not the first blk
            if (oeb->next == NULL) {     // Last blk?
               oeb->prev->next = NULL;   // Drop this blk from the list
               free(oeb);
               return(0);
            }
            else {                       // Not the last blk, it must be a blk in the middle
               oeb->prev->next = oeb->next;
               oeb->next->prev = oeb->prev;
               free(oeb);
               return(0);
            }
         }
      }
   } while ((oeb = oeb->next) != NULL);

   return(-1);      // Can't find it in the list
}


// If die() is called from an on-exit function, the recursion is
// detected.  Processing the on-exit list continues with the next
// registered function after the on that made the recursive call.

// Note: For backtrace() to work correctly you must use -rdynamic
//       option when linking.

void die(int line, char *file, char *msg, ...)
{
   int no_trace = 0;           // Default (0) is to print backtrace.
   va_list args;
   static int recursive = 0;
   static struct ON_EXIT_BLK *oeb      = NULL;

   char scrap[1024];

   verbose = 0;
   if (recursive) {

      // An on_exit() function must have called die()!
      fprintf(stderr, "* Recursive call from file %s line %d !\n", file, line);

      oeb = oeb->next;  // Continue to the next on_exit() function
   }
   else {
      oeb = oeb_head;   // First call to die().  Setup to call on_exit() functions
      recursive = 1;       // Flag the fact that we have been here before

      // Call on_exit functions

      while (oeb != NULL) {
         (*oeb->func)();
         oeb = oeb->next;
      }
   }
   if (file == NULL) file = "Not specified";

   fprintf(stderr, "\n****************************************************************\n");
   fprintf(stderr, "*\n");

   // Don't printf line/file info if not specified

   if (strlen(file) || line) {
      fprintf(stderr, "* Program exit at line: %d file: %s\n", line, file);
   }
   fprintf(stderr, "*\n");

   if (msg != NULL) {
      va_start(args, msg);
      vsnprintf(scrap, sizeof(scrap), msg, args);
      fprintf(stderr, "* %s\n", scrap);
      fprintf(stderr, "*\n");
   }
   fprintf(stderr, "*\n");

   fprintf(stderr, "*\n");

   fprintf(stderr, "****************************************************************\n");
   fprintf(stderr, "Press any  key to exit...");
   getch();

   exit(0);
}


