/*
===============================================================================
                            COPYRIGHT NOTICE

    Copyright (C) 2012 Vista Instrumentation LLC
    International Copyright Secured.  All Rights Reserved.

-------------------------------------------------------------------------------

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

   o Redistributions of source code must retain the above copyright notice, this
     list of conditions and the following disclaimer.
   o Redistributions in binary form must reproduce the above copyright notice,
     this list of conditions and the following disclaimer in the documentation
     and/or other materials provided with the distribution.
   o Neither the name of Vista Instrumentation nor the names of its contributors may be used
     to endorse or promote products derived from this software without specific
     prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================
*/

// Vista Geometry System RECORD server command string definitions

#define  STRT          "RecCtrl STRT"                   // Start recording
#define  STOP          "RecCtrl STOP"                   // Stop recording
#define  PAUSE         "RecCtrl PAUSE"                  // Pause recording
#define  RUN           "RecCtrl RUN"                    // Un-pause recording
#define  POST          "RecCtrl POST"                   // Load Post incrementing mode
#define  AUTO_POST_INC "RecCtrl AUTO_POST_INC"          // Turn on auto post increment
#define  AUTO_POST_DEC "RecCtrl AUTO_POST_DEC"          // Turn on auto post Decrement
#define  AUTO_POST_OFF "RecCtrl AUTO_POST_OFF"          // Turn on auto post Decrement
#define  AUTO_REC_ON   "RecCtrl AUTO_REC_ON"            // Turn on automatic recording
#define  AUTO_REC_OFF  "RecCtrl AUTO_REC_OFF"           // Turn off automatic recording
#define  EVENT         "RecCtrl EVENT"                  // Load event
#define  USER_DATA     "RecCtrl USER_DATA"              // Load user data
#define  NEXT_POST     "RecCtrl NEXT_POST"              // 13 Increment or decrement the post
#define  PAR_ERROR     "RecCtrl PERR"                   // 14 Trigger gyro parity error
#define  LD_TACH       "RecCtrl LD_TACH"                // 15 Load hardware tach reg
#define  PROF_ON       "RecCtrl PROFILE_ON"             // 16 Enable profile recording
#define  PROF_OFF      "RecCtrl PROFILE_OFF"            // 17 Disable profile recording
#define  NEW_FILE      "RecCtrl NEW_FILE"               // 18 Close current file and enter a new one
#define  CHAN_EN       "RecCtrl CHANNEL_ON"             // 19 Enable geometry data channel
#define  CHAN_DEN      "RecCtrl CHANNEL_OFF"            // 20 Disable geometry data channel
#define  GAUGE_PNT     "RecCtrl GAUGE_PNT"              // 21 Set gauge point




