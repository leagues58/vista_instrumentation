// Disable 'loss of precision', 'double to float', size_t/int, classic libc warnings
#pragma warning(disable : 4305 4244 4267 4996)

