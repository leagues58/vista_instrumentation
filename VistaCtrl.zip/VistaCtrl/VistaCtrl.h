#define SERVER_RESPONSE_LEN   (512)

extern void dump_data(void);

extern int get_rt_mode(void);
extern DWORD WINAPI realtime_thread(void *arg);
extern DWORD WINAPI udp_comm_thread(void *arg);

